package com.karyaku.kasir

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.karyaku.kasir.data.local.CashFlowEntity
import com.karyaku.kasir.data.local.ShiftEntity
import com.karyaku.kasir.data.local.TransactionEntity

@Composable
fun CloseShiftWizardDialog(
    shift: ShiftEntity,
    transactions: List<TransactionEntity>,
    cashFlows: List<CashFlowEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Long, String) -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var physicalCashInput by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val physicalCash = physicalCashInput.toLongOrNull() ?: 0L

    // Kalkulasi
    val totalPenjualan = transactions.filter { 
        it.timestamp >= shift.startTime 
        && it.status == "SUCCESS" 
        && it.paymentMethod == "CASH"
    }.sumOf { it.totalPrice }
    
    // FIX: Menggunakan shiftId yang sekarang sudah diisi dengan benar oleh addCashFlow
    val totalKasKeluar = cashFlows.filter { it.shiftId == shift.id && it.type == "OUT" }.sumOf { it.amount }
    val totalKasMasuk = cashFlows.filter { it.shiftId == shift.id && it.type == "IN" }.sumOf { it.amount }
    val expectedCash = shift.openingCash + totalPenjualan + totalKasMasuk - totalKasKeluar
    val discrepancy = physicalCash - expectedCash
    val isDiscrepancy = discrepancy != 0L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tutup Kasir (Langkah $step dari 3)", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                when (step) {
                    1 -> {
                        Text("Masukkan total uang fisik yang ada di dalam laci kasir saat ini.", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = physicalCashInput,
                            onValueChange = { if (it.length <= 12) physicalCashInput = it },
                            label = { Text("Uang Fisik (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    2 -> {
                        Text("Sistem telah menghitung total uang yang seharusnya ada.", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Modal Awal:"); Text(formatRupiah(shift.openingCash))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Penjualan Tunai:"); Text(formatRupiah(totalPenjualan))
                        }
                        if (totalKasMasuk > 0) Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kas Masuk:"); Text(formatRupiah(totalKasMasuk))
                        }
                        if (totalKasKeluar > 0) Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kas Keluar:"); Text("- ${formatRupiah(totalKasKeluar)}")
                        }
                        
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kas Sistem:", fontWeight = FontWeight.Bold); Text(formatRupiah(expectedCash), fontWeight = FontWeight.Bold, color = EmeraldGreen)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kas Fisik:", fontWeight = FontWeight.Bold); Text(formatRupiah(physicalCash), fontWeight = FontWeight.Bold)
                        }
                        
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Selisih:", fontWeight = FontWeight.Bold)
                            Text(
                                formatRupiah(discrepancy), 
                                fontWeight = FontWeight.ExtraBold,
                                color = if (discrepancy < 0) ErrorRed else if (discrepancy > 0) AmberAccent else EmeraldGreen
                            )
                        }
                    }
                    3 -> {
                        Text("Terdapat selisih uang sebesar ${formatRupiah(discrepancy)}.", fontSize = 14.sp, color = ErrorRed, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Wajib memberikan catatan alasan selisih (misal: uang kembalian kurang, tip, dll).", fontSize = 12.sp, color = SlateGrey)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Catatan Selisih") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            when (step) {
                1 -> Button(
                    onClick = { step = 2 }, 
                    enabled = physicalCashInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Lanjut ke Kalkulasi") }
                
                2 -> Button(
                    onClick = { 
                        if (isDiscrepancy) step = 3 
                        else onConfirm(physicalCash, "Tidak ada selisih") 
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(if (isDiscrepancy) "Lanjut" else "Tutup Kasir") }
                
                3 -> Button(
                    onClick = { onConfirm(physicalCash, note) },
                    enabled = note.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Selesaikan & Tutup Kasir") }
            }
        },
        dismissButton = {
            if (step > 1) {
                TextButton(onClick = { step-- }) { Text("Kembali", color = SlateGrey) }
            } else {
                TextButton(onClick = onDismiss) { Text("Batal", color = SlateGrey) }
            }
        }
    )
}